;<?php die(''); ?>
;for security reasons , don't remove or modify the first line

startModule = "junittests"
startAction = "default:index"
