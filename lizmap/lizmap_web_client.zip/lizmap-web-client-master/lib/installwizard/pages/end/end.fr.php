<?php

$locales = array(

  'title'=>'Fin',
  'finish'=>'L\'installation est terminée',

);
