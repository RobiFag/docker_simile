<?php

$locales = array(

    'title'=>'Application installation',

    'install.start'=>'Installation starts..',
    'install.end'=>'End',
    
    'installation.ok'=>'The installation is a success',
    'installation.cancelled'=>'The installation has failed. Fix the errors and reload this page.',

);
