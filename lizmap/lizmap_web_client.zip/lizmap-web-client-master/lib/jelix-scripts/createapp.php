<?php
/**
* @package     jelix-scripts
* @author      Laurent Jouanneau
* @copyright   2011 Laurent Jouanneau
* @link        http://jelix.org
* @licence     GNU General Public Licence see LICENCE file or http://www.gnu.org/licenses/gpl.html
*/

$commandName = 'createapp';

require (__DIR__.'/includes/scripts.inc.php');
