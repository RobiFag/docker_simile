Building assets
===============

Follow those [instructions](../CONTRIBUTING.md#building-javascript-only).
